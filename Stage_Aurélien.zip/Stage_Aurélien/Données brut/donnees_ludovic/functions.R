require(ggplot2)
require(reshape2)


plotFlexFluxTable <- function(fileName, cols = c("Time","Carbon1", "Carbon2", "RPcl", "Tc1", "Tc2", "Biomass"), xmin=NA, xmax=NA) 
{
  df <- read.table(fileName, header=TRUE, sep="\t")
  df_filt <- df[,cols]
  
  df_plot <- melt(df_filt, id="Time") 
  
  gg <- ggplot(df_plot, aes(x=Time, colour=variable, y = value)) + geom_line() 
  
  if(!is.na(xmin) || !is.na(xmax))
    gg <- gg +xlim(xmin, xmax)
  
  gg
  
}