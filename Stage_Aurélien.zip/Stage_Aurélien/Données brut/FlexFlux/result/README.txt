Chacun des 18 réseaux obtenus avec le jeu de données discrétisés (Tc1 initialisé à 0) ont été passé dans Flexflux
Parmis ces 18 réseaux, aucun à part le 10ème (qui représente le réseau de la publication) ne reproduit la diauxie

Pourquoi Caspo sélectionne-t-il ces réseaux dans ce cas ? Plusieurs hypothèses sur la source du problème:
- Le code de Caspo en lui même
- Le réseau ne peut pas être expliqué uniquement en booléen => besoin d'une solution hybride avec des contraintes linéaires
- Peut être laisse-t-on trop de liberté aux interractions de Rpc1

