Ces 2 réseaux sont tirés de l'apprentissage Caspots sur les données discrétisées_Tc1_0 avec le rajout des relations artificielles sur C1 et C2 via le partial-BN (voir le dossier "Discrétisé" dans Caspo-wd)

paramètres utilisés:
- Family subset
- Mincard-tolerance 0
- Weight-tolerance 0
- No-fully-controllable
- Partial-bn comme indiqué plus haut

Caspots n'apprend cette fois que 2 réseaux, dont le réseau de la littérature (ce qui est plutôt bon signe)
Avec Flexflux, on retrouve bien la diauxie dans ce réseau (network1)

Pour l'autre réseau, Caspots juge que c'est une solution au jeu de données, mais l'analyse Flexflux n'affiche pas de diauxie apparente
Le problème étant que RPc1 inhibe Tc1 dans ce réseau, ce qui produit des oscillations (Tc1 active RPc1 et la croissance, mais au temps suivant RPc1 inhibe Tc1, s'inhibant par la même occasion, puis le pattern recommence)
Mais cela lève l'inhibition de Tc2 (sensé restée jusqu'à l'épuisement de la source de carbone 1), et au final les deux sources de carbone sont utilisées en même temps et par à-coups
Néanmoins l'avancée est considérable par rapport aux 18 réseaux issus des analyses précédentes et qui n'avaient pas vraiment de sens, reste à savoir pourquoi le réseau n°2 est considéré comme viable par Caspo

Il faudrait recouper ça avec l'article d'Alexander qui proposait une boucle de rétrocontrôle de RPc1 sur gTc1, mais une régulation de RPc1 par le carbone 1 et non Tc1
