Résultat de l'analyse des 2 réseaux trouvés par Caspots avec le dataset_oxygen discrétisé

Les 2 réseaux présentent la diauxie, l'oxygène agit comme une 3ème source pour la biomasse, mais est consommé soit en même temps que le carbone1 (réseau 1), soit en même temps que le carbone 2 (réseau 2).

Cependant, ces réseaux n'ont pas vraiment de sens biologiquement parlant, l'oxygène agit indirectement dans le cycle comme une source d'ATP, et n'est pas du tout suffisante à elle seule pour générer de la biomasse.

Les résultats en restent néanmoins intéressant sur le plan technique, Caspots semble tout à fait capable avec les bonnes entrées de retrouver les réseaux adéquats.
