Paramètres utilisés:
- family subset
- mincard-tolerance 0
- weight-tolerance 0
- no-fully-controllable

Pas de partial-BN, mais le .sif donné décrivait un réseau exact

Caspo identifie 2 réseaux et en valide 2, l'un est la solution
MSE = 0
Il hésite sur la relation "ET" ou "OU" vers vTc2

