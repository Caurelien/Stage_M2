Tentatives avec le réseau adapté de la publication d'Alexander:

- En l'adaptant exactement en .sif, Caspo n'arrive même pas à retrouver le bon
Après des tests en enlevant gTc1, il trouve la bonne solution, le problème viens donc de la
Caspo a déjà des problèmes pour gérer l'auto-inhbition des 2 carbones, alors un 3ème noeuds...
