Paramètres utilisés:
- family subset
- mincard-tolerance 0
- weight-tolerance 0
- no-fully-controllable
- partial-bn MiniToy_dnf_alexander.txt

Caspo identifie et valide 6 réseaux, parmi ces réseaux se trouve le bon
Les problèmes sont globalement les mêmes qu'avec le jeu de test discrétisé_Tc1_0, mais le nombre de réseaux "déchets" est globalement moins élevé
Il y a peut être un effet tampon avec les noeuds rajoutés entre
