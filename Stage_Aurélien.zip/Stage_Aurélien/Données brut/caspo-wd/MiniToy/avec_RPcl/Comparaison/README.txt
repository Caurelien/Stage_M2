Voila les résultats obtenus (dans l'ordre), les 18 réseaux sont compris dans les 22, et eux même dans les 40

- Numérique: jeu de données de base envoyé par Ludovic

- Booléanisé: jeu de données de base mais ou les valeurs ont été approximées en 0 et en 1 (Ex: 0.3 devient 0 et 0.7 devient 1)
Le point initial comprend une activation de Tc2 très brève avant que le Rpc1 vienne l'inhiber (un point que l'on avait pas dans le jeu de base), c'est pourquoi il a été rajouté

- Discrétisé/fait-main: jeu de données en 0 et 1 créé à la main à partir de la cinétique Flexflux de ludovic, il s'agit d'un "update" des états de chaque molécules en fonction du point de temps précédent, le point de temps initial est inclu


Pour les paramètres utilisés:
Subset
- mincard-tolerance 0
- weight-tolerance 0

Mincard
- mincard-tolerance 1
- weight-tolerance 0



NUMERIQUE SANS POINT INITIAL
-Subset: 40 réseaux
-Mincard_1_0: 15 réseaux
-MSE=1.111
Le réseau d'intérêt est retrouvé dans les 2 cas

BOOLEANISE SANS POINT INITIAL
-Subset: 40 réseaux
-Mincard_1_0: 15 réseaux
-MSE=0
Le réseau d'intérêt est retrouvé dans les 2 cas

BOOLEANISE AVEC POINT INITIAL
-Subset: 22 réseaux
-Mincard_1_0: 9 réseaux
-MSE=0
Le réseau d'intérêt est retrouvé dans les 2 cas

BOOLEANISE AVEC POINT INITIAL SANS REDONDANCE (pareil qu'avec la redondance)
-Subset: 22 réseaux
-Mincard_1_0: 9 réseaux
-MSE=0
Le réseau d'intérêt est retrouvé dans les 2 cas

DISCRETISE/FAIT-MAIN AVEC TC1 INITIALISE A 1
-Subset: 22 réseaux
-Mincard_1_0: 9 réseaux
-MSE=0
Le réseau d'intérêt est retrouvé dans les 2 cas

DISCRETISE/FAIT-MAIN AVEC TC1 INITIALISE A 0
-Subset: 18 réseaux
-Mincard_1_0: 8 réseaux
-MSE=0
Le réseau d'intérêt est retrouvé dans les 2 cas



Le booléanisé sans le point initial donne les mêmes résultats que le numérique, ce n'est donc pas le fait de discrétiser qui change les résultats, mais de capturer les bons points
Cela peut expliquer la différence entre le booléanisé avec point initial et le discrétisé

Rajouter le point initial dans le booléanisé donne les mêmes résultats que le discrétisé avec Tc1 initialisé à 1
Je suppose que si l'on rajoutait un point initial au numérique on retrouverait la même chose aussi

Qu'importe le jeu de données et les paramètres, le réseau ou Rpc1 active Tc2 (en relation "ET" avec le carbon2) est toujours présent
Dans le booléanisé, ce n'est donc pas le fait de la redondance
Il est néanmoins minoritaire par rapport à la proportion de réseaux ou Rpc1 inhibe Tc2 (en relation "ET" avec le carbon2)

La relation Rpc1 sur Tc1 est indépendante de la relation "ET" (Tc2 <= carbon2 ET !Rpc1)
