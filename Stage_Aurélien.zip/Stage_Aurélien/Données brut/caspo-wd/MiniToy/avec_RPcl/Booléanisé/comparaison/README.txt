Comparaison des 3 jeux de données:
- Données booléanisées
- Données booléanisées avec le point initial rajouté
- Données booléanisées avec le point initial rajouté, et les points redondants enlevés

Les observations sont les mêmes, quelque soit les paramètres employés (mincard ou subset)
- Il y a moins de réseaux trouvés en rajoutant le point de temps initial, le réseau d'intérêt issu de la publication est trouvé dans tous les cas
Subset: on passe de 40 réseaux à 22
Mincard_1_0: on passe de 15 réseaux à 9

- Enlever les points de temps redondants n'influent pas sur les résultats, ce sont les mêmes qu'avec le point de temps initial
Subset: 22 réseaux trouvés
Mincard_1_0: 9 réseaux trouvés
