Paramètres utilisés:
- family subset
- mincard-tolerance 0
- weight-tolerance 0
- no-fully-controllable
- partial-bn MiniToy_dnf.txt

Résultats "Identify": 40 réseaux trouvés
Résultats "Validate": 40 réseaux validés (100%)
MSE: 0

Le réseau d'intérêt est présent

