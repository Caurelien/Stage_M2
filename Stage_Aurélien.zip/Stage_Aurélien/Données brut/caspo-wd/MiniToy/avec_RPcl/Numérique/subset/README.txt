Paramètres utilisés pour la commande "identify":
- family subset
- mincard-tolerance 0
- weight-tolerance 0
- no-fully-controllable
- partial-bn MiniToy_dnf.txt

Après exécution de identify et validate, 40 réseaux sont trouvés
Le détail est disponible dans output_validate.csv, visuel dans output_validate.png

Parmis ces 40 réseaux, 19 possèdent la relation Tc2 = !Rpcl ET carbon2 (le 3ème, le 6ème, les 9 et 10ème, puis du 26ème au 40ème)
Les informations sur ces réseaux ont été extraites dans dataset_focus.csv, visuel dans le fichier .png du même nom

Parmis ces 19 réseaux, seul le 6ème présente très exactement les mêmes caractéristiques que le réseau de la littérature
Le détail est dans dataset_solution.csv, visuel dans le .png du même nom

Parmis les 40 réseaux, aucun ne présente la relation Tc2 = !Rpcl OU carbon2

MSE discrete = 0.11121545554
MSE sample >= MSE discrete
