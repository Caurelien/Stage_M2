Paramètres utilisés dans la commande "identify":
- family mincard
- mincard-tolerance 1
- weight-tolerance 0
- no-fully-controlable
- partial-BN miniToy_dnf.sif

Nb de réseaux trouvés après identify + validate: 15

parmis ces 15 réseaux, 3 possèdent la relation Tc2 = !Rpcl ET Carbon2 (les réseaux 11, 12 et 13). Le détail est dans output_validate.csv et output_validate.png

Extraction de ces 3 réseaux dans dataset_focus_on3_networks_with_relation.csv
Visuel dans le fichier .png du même nom

Parmis ces 3 réseaux, un seul concorde parfaitement avec le réseau issu de la littérature(le 11)
Extraction de ce réseau dans dataset_solution.csv, visuel dans le fichier .png du même nom

Parmis les 15 réseaux, aucun ne présente la relation Tc2 = !Rpcl OU carbon2

MSE discrete: 0.11121545554
MSE sample >= MSE discrete

