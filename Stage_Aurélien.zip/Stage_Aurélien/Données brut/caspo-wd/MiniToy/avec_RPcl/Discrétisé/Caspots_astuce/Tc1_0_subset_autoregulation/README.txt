Paramètres utilisés:
- MiniToy_test.sif
- datatest_Tc1_0.csv
- family subset
- mincard-tolerance 0
- weight-tolerance 0
- no-fully-controllable
- partial-bn MiniToy_dnf_test.txt

Résultats "Identify": 8 réseaux trouvés
Résultats "Validate": 2 validés (25%)
MSE = 0

En changeant la méthode d'update des état des 2 carbones, on a grandement filtré le nombre de réseaux "défaillants" trouvés par Caspo. Ces réseaux devaient être expliqués par le changement d'état ??? (aléatoire, dissident) des 2 carbones.
le réseau d'intérêt est présent! Mais il en valide un autre, à voir si celui-ci peut aussi expliquer la diauxie
