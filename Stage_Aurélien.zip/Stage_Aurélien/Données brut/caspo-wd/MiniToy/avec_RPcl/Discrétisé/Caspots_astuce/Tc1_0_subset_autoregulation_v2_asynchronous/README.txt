Ce nouveau MIDAS v2 prend en compte le changement d'activation (de Tc1=>RPc1 à C1=>RPc1)
Le partial-bn a du être un peu modifié pour prendre en compte ce nouveau MIDAS

Les paramètres utilisés sont toujours les mêmes, la différence est que la méthode de validate a été fixé à "asynchronous"
Réseaux identifiés: 4
Réseaux validés: 1
MSE = 0

Si on laisse la méthode à "General", on valide 2 réseaux, et le 2nd ne présente pas la diauxie
