Paramètres utilisés:
- family mincard
- mincard-tolerance 1
- weight-tolerance 0
- no-fully-controllable
- partial-bn MiniToy_dnf.txt

Résultats "Identify": 8 réseaux trouvés
Résultats "Validate": 8 réseaux validés (100%)
MSE: 0

2 réseaux présentes la relation "ET"
Parmis ces 2 réseaux, celui nous intéressant est présent
