Paramètres utilisés:
- family subset
- mincard-tolerance 0
- weight-tolerance 0
- no-fully-controllable
- partial-bn MiniToy_dnf.txt

Résultats "Identify": 22 réseaux trouvés
Résultats "Validate": 22 validés (100%)
MSE = 0

8 réseaux possèdent la relation "ET"
Parmis ces 8 réseaux, l'un représente notre réseau issu de la littérature
