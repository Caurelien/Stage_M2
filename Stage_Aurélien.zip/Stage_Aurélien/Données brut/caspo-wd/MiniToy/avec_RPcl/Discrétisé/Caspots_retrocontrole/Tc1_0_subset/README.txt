Paramètres utilisés:
- family subset
- mincard-tolerance 0
- weight-tolerance 0
- no-fully-controllable
- partial-bn MiniToy_dnf.txt

Résultats "Identify": 18 réseaux trouvés
Résultats "Validate": 18 validés (100%)
MSE = 0

8 réseaux possèdent la relation "ET"
Parmis ces 8 réseaux, l'un représente notre réseau issu de la littérature

Les réseaux "synchronous" et "synchronous_test" représentent dans l'ordre:
- Les 4 réseaux validés en update synchrone avec les paramètres décrits au dessus
- Les 6 réseaux validés en update synchrone avec les paramètres décrits au dessus, hormis le partial-bn qui ne donne aucune indication sur Tc1

Les réseaux triés ainsi possèdent tous la relation Tc2 <- Carbon2 + !Rpc1
Le problème c'est qu'on ne retrouve pas le réseau d'intérêt, aucun de ces réseaux ne trouvent la relation Rpc1 <- Tc1

Notre réseau d'intérêt ne peut-il être trouvé qu'en asynchrone ? Ou bien y a-t-il un problème à creuser dans cette relation entre Tc1 et Rpc1 ?

