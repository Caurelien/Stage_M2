Toutes les relations ont été floutées, toutes les intéractions rendues possibles, et aucune relation n'a été fixées à l'aide du partian-BN

En subset:
576 réseaux ont été identifiés, et 542 ont été validés (le réseau solution s'y trouve)

En mincard:
92 réseaux identifiés, et 92 validés

Caspots perd grandement en précision lorsqu'on lui laisse trop de liberté dans les relations, il est donc très important de tenter de fixer le plus de relation possible basé sur la littérature, et d'itérer seulement sur un nombre restreint de relations inconnues

Au niveau des performances, la nouvelle version de Caspots est extrèmement rapide, les 576 réseaux ont été identifiés en environ 3 sec, et la validation a pris à peu près 4 sec.
