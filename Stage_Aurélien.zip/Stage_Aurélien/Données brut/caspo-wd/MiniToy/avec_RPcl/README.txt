Voila un petit guide présentant une description des différents dossiers (et fichiers) se trouvant ici:

Les résultats d'analyses ont été obtenus sur 3 jeux de données, qui sont rangés dans 3 dossiers respectifs:
- "Numérique" contient tous les résultats obtenus avec le MIDAS de Ludovic Cottret (données cinétiques avec FlexFLux)
- "Booléanisé" contient les résultats obtenus par le MIDAS numérique, mais discrétisé (une valeur de 0.3 est passé à 0 par exemple)
- "Discrétisé" contient les résultats via un MIDAS fait main (tout en 0 et en 1) sensé traduire la cinétique obtenu via FlexFLux

- "Comparaison" comme son nom l'indique regroupe des comparaisons visuels (et parfois numériques) entre les 3 jeux de données

- "out" est le dossier de sortie par défaut de Caspo, c'est ici que sortent les résultats en attendant de savoir ou les mettre...

- Publication_alexander concerne tous les résultats de la publication évoqué par alexander

Pour les fichiers et scripts:
- dataset.csv est le MIDAS "numérique"
- datatest_carbon.csv est un MIDAS test ou l'activation Tc1 => Rpc1 est switché à Carbon1 => Rpc1 (non concluant)
- datatest_Tc1_0 et datatest_Tc1_1.csv sont les 2 MIDAS "discrétisé" (Tc1 initialisé à 1 ou à 0), celui qui a été gardé pour les analyses est datatest_Tc1_0.csv
- MiniToy.sif est le PKN (Prior Knowledge Network) partiel du réseau de la publication Diauxie (partiel car Rpc1 est laissé libre)
- MiniToy_dnf.txt est une réponse partielle permettant de fixer certaines intéractions (à donner en argument à la commande "identify")
- minitoy_test.sif est le PKN test lié à datatest_carbon.csv
- setup.json permet de fixer les stimulis, inhibitions et read-outs (s'en référer à la doc de Caspo pour plus de détails)

- caspo est un mini-script permettant d'éviter de retaper la commande d'appel de docker en entier à chaque fois
- caspots, même chose
ATTENTION: en cas de copier-coller pour utilisation dans un autre dossier, il faudra peut être changer les répertoirs indiqués dans les commandes

- validate permet d'éviter de retaper la commande en entier
ATTENTION: il faut adapter les arguments en conséquence des données

- visualize est un raccourci pour la commande visualize
