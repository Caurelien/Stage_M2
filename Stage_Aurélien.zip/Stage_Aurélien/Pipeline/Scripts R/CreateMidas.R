#!/usr/bin/env Rscript
args = commandArgs(trailingOnly=TRUE)
if(!require(tibble)){install.packages("tibble")}
tab1 = read.table(args[1], header=TRUE)
tab1$X = NULL
tab1$Time = NULL
tab1 <- round(tab1,2)
dv_cols <- colnames(tab1)
da_cols <- colnames(tab1)
dv_cols <- paste0("DV:",dv_cols)
da_cols <- paste0("DA:",da_cols)
names(tab1) <- c(dv_cols)
num = 1
for (char in dv_cols){
  tab1 = add_column(tab1, !!(da_cols[num]) := 0:(nrow(tab1)-1),.before = char)
  num = num + 1
}
tab1 = add_column(tab1, "TR:Cell:CellLine" = 1,.before = da_cols[1])
write.csv(x=tab1, file="Midas.csv", row.names = FALSE)
