#!/usr/bin/env Rscript
args = commandArgs(trailingOnly=TRUE)
tab2 = read.csv(args[1], header=TRUE)
dv_cols <- grep("DV", colnames(tab2))
dv_tab = tab2[,dv_cols]
for (row in 1:nrow(dv_tab)){
  for (col in 1:ncol(dv_tab)){
    if (dv_tab[row,col] <= args[2]){
      dv_tab[row,col] = 0
    }
    if (dv_tab[row,col] > args[2]){
      dv_tab[row,col] = 1
    }
  }
}
tab2[,dv_cols] <- dv_tab
colnames(tab2) = gsub("[.]",":",colnames(tab2))
write.csv(x=tab2, file="Discretize.csv", row.names = FALSE)
