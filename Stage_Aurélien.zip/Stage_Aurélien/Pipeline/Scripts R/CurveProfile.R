#!/usr/bin/env Rscript
args = commandArgs(trailingOnly=TRUE)
tab3 <- read.csv(args[1],header=TRUE)
dv_cols <- grep("DV", colnames(tab3))
dv_tab = tab3[,dv_cols]
dv_tab_final <- dv_tab
for (row in 1:(nrow(dv_tab)-1)){
  for (col in 1:ncol(dv_tab)){
    if ((dv_tab[row+1,col]-dv_tab[row,col]) == 0){
      dv_tab_final[row,col] = "="
    }
    if ((dv_tab[row+1,col]-dv_tab[row,col]) > 0){
      dv_tab_final[row,col] = "+"
    }
    if ((dv_tab[row+1,col]-dv_tab[row,col]) < 0){
      dv_tab_final[row,col] = "-"
    }
  }
}
tab3[,dv_cols] <- dv_tab_final
tab3 <- tab3[-c(nrow(tab3)),]
write.csv(x=tab3, file="CurveProfile.csv", row.names = FALSE)
