---------------------------
INSTRUCTIONS
---------------------------

Les 4 scripts permettent de pré-traiter les données (module de pré-traitement du pipeline), le langage R doit être installé pour utiliser ces scripts
Pour les utiliser, ouvrir la console et utiliser la commande: Rscript "nomduscript" "argument1" "argument2" "etc" (sans les guillemets)
Il est aussi possible de les éxécuter via Rstudio (voir environnement Conda)

--------------------------
CreateMidas.R
--------------------------

- Prend en argument le tableau des cinétiques au format txt en sortie de FlexFlux (exemple: Rscript CreateMidas.R cinetique.txt)
- Permet de passer le tableau au format MIDAS
- Le fichier en sortie est appelé "Midas.csv"

--------------------------
FilterTimeSeries.R
--------------------------

- Prend en argument un tableau de données au format MIDAS (exemple: Rscript FilterTimeSeries.R Midas.csv)
- Filtre les points de temps redondants
- Le fichier en sortie est appelé "Filtered.csv"

--------------------------
Discretize.R
--------------------------

- Prend en argument, dans l'ordre, un tableau de données au format MIDAS et un nombre décimal (exemple: Rscript Discretize.R Filtered.csv 0.1)
- Discrétise les données par rapport au seuil donné (nombre décimal)
- Le fichier en sortie est appelé "Discretize.csv"

--------------------------
CurveProfile.R
--------------------------

- Prend en argument un tableau de données au format MIDAS (exemple: Rscript CurveProfile.R Filtered.csv)
- Transforme les données en un tableau de profil de courbe, ou la croissance, décroissance et stagnation sont représentées par "+", "-" et "="
- Le fichier en sortie est appelé "CurveProfile.csv"


