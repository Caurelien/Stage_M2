#!/usr/bin/env Rscript
args = commandArgs(trailingOnly=TRUE)
tab = read.csv(args[1], header=TRUE)
dv_cols <- grep("DV", colnames(tab))
dv_tab = tab[,dv_cols]
fun <- function(x) {y <- 1:length(x); slope <- diff(x)/diff(y) ; slope_disc <- slope ; slope_disc[slope==0] <- 0 ; slope_disc[slope<0] <- -1; slope_disc[slope>0] <- 1; c(0,slope_disc) }
tab_slopes <- apply(dv_tab, 2, fun)
ind <- which(duplicated(tab_slopes))
filtered_tab = tab[-ind,]
colnames(filtered_tab) = gsub("[.]",":",colnames(filtered_tab))
write.csv(x=filtered_tab, file="Filtered.csv", row.names = FALSE)
