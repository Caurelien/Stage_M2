---------------------
Pipeline
---------------------

Tout ce qu'il faut pour faire tourner le pipeline, à part FlexFlux qu'il faut télécharger via le github de Ludovic Cottret, il faut lancer l'environnement FlexFlux pour utiliser les commandes FlexFlux

---------------------
MiniToy
---------------------

Regroupe les fichiers d'éxécutions Caspots et FlexFlux pour les expériences sur l'exemple MiniToy

---------------------
Covert
---------------------

Tentative incomplete de l'adaptation du réseau en entier, regroupe les fichiers d'éxécutions FlexFlux et Caspots

---------------------
Données brut
---------------------

Le bazard le plus total, toutes les tentatives et résultats plus ou moins rangés dans des dossiers...
J'ai essayé d'y mettre un peu d'ordre, mais même moi j'ai du mal à m'y retrouver

Le plus important reste le pipeline et les fichiers d'éxécutions
